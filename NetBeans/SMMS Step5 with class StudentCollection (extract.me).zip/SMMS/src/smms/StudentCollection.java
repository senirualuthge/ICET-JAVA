/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package smms;

/**
 *
 * @author pc
 */
public class StudentCollection {
   private static Student[] studentArray=new Student[0]; 
       public static boolean addNeStudent(Student student){
        Student[] tempStudentArray=new Student[studentArray.length+1];
        for (int i = 0; i < studentArray.length; i++) {
            tempStudentArray[i]=studentArray[i];
        }
       studentArray=tempStudentArray;
       studentArray[studentArray.length-1]=student;
       return true;
    }
    public static Student searchStudent(String id){
        for (int i = 0; i < studentArray.length; i++) {
            if(id.equalsIgnoreCase(studentArray[i].getId())){
                return studentArray[i];
            }
        }
        return null;
    }
}
